(async () => {
    const localStorage = await chrome.storage.local.get();

    if (localStorage["defaultSettingsUrl"] == null) {
        await chrome.storage.local.set({ defaultSettingsUrl: "https://www.google.com/" });
    }

    let CRPEnabled = false;
    let alertThrown = false;
    let CRPRunning = false;
    let refreshIntervalId = null;
    let requestStartTimes = {}; 
    let alertedErrors = {}; 

    const clearCache = (function () {
        if (!CRPRunning) {
            if (typeof chrome.browsingData !== "undefined") {
                CRPRunning = true;
                const millisecondsPerWeek = 1000 * 60 * 60 * 24 * 7;
                const oneWeekAgo = new Date().getTime() - millisecondsPerWeek;

                chrome.browsingData.removeCache(
                    {
                        since: oneWeekAgo,
                    },
                    function () {
                        CRPRunning = false;
                    }
                );
            } else if (!alertThrown) {
                alertThrown = true;
                alert("browsingData API를 사용할 수 없습니다!");
            }
        }
    });

    const refreshTabs = () => {
        chrome.storage.local.get("refreshOption", (data) => {
            const refreshOption = data.refreshOption || "none"; // 기본값 "none"

            if (refreshOption === "allTabs") {
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach((tab) => {
                        if (tab.id) {
                            chrome.tabs.reload(tab.id);
                        }
                    });
                });
            } else if (refreshOption === "firstTab") {
                chrome.tabs.query({}, (tabs) => {
                    if (tabs.length > 0 && tabs[0].id) {
                        chrome.tabs.reload(tabs[0].id);
                    }
                });
            }
        });
    };

    const enableAct = (function () {
        CRPEnabled = true;
        chrome.action.setIcon({ path: "icon_on.png" });
        chrome.action.setTitle({ title: "CRP 활성화됨" });
        chrome.webRequest.onBeforeRequest.addListener(clearCache, { urls: ["<all_urls>"] });

        if (!refreshIntervalId) {
            refreshIntervalId = setInterval(refreshTabs, 60000); // 1800000ms = 30min
        }
    });

    const disableAct = (function () {
        CRPEnabled = false;
        chrome.action.setIcon({ path: "icon_off.png" });
        chrome.action.setTitle({ title: "CRP 비활성화됨" });
        chrome.webRequest.onBeforeRequest.removeListener(clearCache);

        if (refreshIntervalId) {
            clearInterval(refreshIntervalId);
            refreshIntervalId = null;
        }
    });

    const flipStatus = (function () {
        if (CRPEnabled) {
            disableAct();
        } else {
            enableAct();
        }
    });

    chrome.action.onClicked.addListener(flipStatus);

    if (localStorage["turnOnByDefault"] === "on") {
        enableAct();
    } else {
        disableAct();
    }

    fetch(localStorage["defaultSettingsUrl"])
        .then((response) => response.json())
        .then((settings) => {
            if (settings.enable) {
                enableAct();
            } else {
                disableAct();
            }
        })
        .catch(() => {});

    const showAlertOnPageLoadError = (details) => {
        if (details.error) {
            const tabId = details.tabId;
            const startTime = requestStartTimes[details.requestId];
            const currentTime = new Date().getTime();
            const elapsedTime = currentTime - startTime;

            if (!alertedErrors[tabId]) {
                alertedErrors[tabId] = new Set();
            }
            //7초이상 장애 지속 
            if (elapsedTime >= 7000 && !alertedErrors[tabId].has(details.error)) {
                alertedErrors[tabId].add(details.error); 
                const errorMessage = `페이지 오류 코드: ${details.error}`;
                const errorPageUrl = `errortab.html?message=${encodeURIComponent(errorMessage)}`;
                chrome.tabs.create({ url: errorPageUrl });

                chrome.tabs.reload(tabId);
            }

            delete requestStartTimes[details.requestId];
        }
    };

    const trackRequestStart = (details) => {
        requestStartTimes[details.requestId] = new Date().getTime();
    };

    const clearRequestStartTime = (details) => {
        delete requestStartTimes[details.requestId];
    };

    chrome.webRequest.onBeforeRequest.addListener(trackRequestStart, { urls: ["<all_urls>"] });
    chrome.webRequest.onErrorOccurred.addListener(showAlertOnPageLoadError, { urls: ["<all_urls>"] });
    chrome.webRequest.onCompleted.addListener(clearRequestStartTime, { urls: ["<all_urls>"] });
})();
