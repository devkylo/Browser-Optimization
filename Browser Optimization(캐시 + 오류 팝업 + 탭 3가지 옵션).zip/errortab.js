document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const errorMessage = urlParams.get('message');
    document.getElementById('errorMessage').textContent = errorMessage;
});