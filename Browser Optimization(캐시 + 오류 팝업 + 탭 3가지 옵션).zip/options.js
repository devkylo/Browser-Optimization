const save = document.getElementById("save");
const enableOnStartElement = document.getElementById("enableOnStartElement");
const refreshOptionElement = document.getElementById("refreshOption");

async function saveOptions() {
    let newValue = "off";
    if (enableOnStartElement.checked) {
        newValue = "on";
    }

    const refreshOption = refreshOptionElement.value;

    await chrome.storage.local.set({
        turnOnByDefault: newValue,
        refreshOption: refreshOption,
    });
}

async function restoreOptions() {
    const localStorage = await chrome.storage.local.get();

    if (localStorage["turnOnByDefault"] === "on") {
        enableOnStartElement.checked = true;
    }

    if (localStorage["refreshOption"]) {
        refreshOptionElement.value = localStorage["refreshOption"];
    } else {
        refreshOptionElement.value = "none"; // 기본값으로 새로고침 해제 설정
    }
}

save.addEventListener("click", saveOptions);
restoreOptions();
